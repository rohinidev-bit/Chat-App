from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('auth', '0011_update_proxy_permissions'),
        ('chat', '0002_auto_20200823_0905'),
    ]

    operations = [
        migrations.RenameModel(
            old_name='ChartGroup',
            new_name='ChatGroup',
        ),
    ]