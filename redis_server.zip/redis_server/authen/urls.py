from django.urls import path
from .views import home
from .views import loginView
from .views import registerView

urlpatterns = [

    path('home/', home, name='homePage'),
    path('login/', loginView, name='loginView'),
    path('register/', registerView, name='registerView'),
]
