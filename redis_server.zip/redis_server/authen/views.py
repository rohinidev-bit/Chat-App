from django.shortcuts import render,redirect
from .models import Users
import mysql.connector
from operator import itemgetter
from django.contrib import messages


def home(request):
    return render(request, 'home.html')


def registerView(request):
    if req.method=="POST":
        user = User()

        user.fname=req.POST['fname']
        user.lname=req.POST['lname']
        user.email=req.POST['email']
        user.password=req.POST['password']
        user.repassword=req.POST['repassword']
        if user.password != user.repassword:
            return redirect("register")
        elif user.fname =="" or user.password=="":
            message.info(req,'Fill every field')
            return redirect('register')
        else:
            user.save()


    return render(request, 'register.html')


def loginView(request):
    con = mysql.connector.connect(host="localhost",user="root",passwd="1000",database="chatdb")
    cursor = con.cursor()
    con2 = mysql.connector.connect(host="localhost",user="root",passwd="1000",database="chatdb")
    cursor2 = con2.cursor()
    sqlcommand = "select email from chatencrypt_user"
    sqlcommand2 = "select password from chatencrypt_user"
    curser.execute(sqlcommand)
    curser2.execute(sqlcommand2)

    e=[]
    p=[]

    for i in cursor:
        e.append(i)
    for i in cursor2:
        p.append(j)
    em = list(map(itengetter(0),e))
    pa = list(map(itengetter(0),p))

    if req.method=="POST":
        email=req.POST['email']
        password=req.POST['password']
        i=1
        k=len(em)
        while i < k:
            if em[i]==email and pa[i]==password:
                return render(req, 'welcome.html',{'email':email})
                break
            i+=1
        else
        messages.info(req,"Check userName or password")
        return redirect('login')
    return render(request, 'login.html')
